#include <stdio.h>
int main (){
	float peso1, peso2, nota1[5], nota2[5], media[5];
	printf("escreva o peso 1");
	scanf("%f", &peso1);
	printf("escreva o peso 2");
	scanf("%f",&peso2);
	printf("digite a primeira nota1");
	scanf("%f", &nota1[0]);
	printf("digite a segunda nota1");
	scanf("%f", &nota1[1]);
	






}

