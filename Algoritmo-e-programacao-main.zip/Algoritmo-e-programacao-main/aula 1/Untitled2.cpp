#include <stdio.h>
int main (){
	int nota1, nota2, media;
	printf("esreva nota1= ");
	scanf("%i", &nota1);
	printf("esreva nota2= ");
	scanf("%i", &nota2);
	
	media = nota1*nota2/2;
	printf("%i", media);
	
	
	
	
	
	
	
	
	
	
}
