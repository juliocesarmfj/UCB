#include <stdio.h>
int main (){
	int numero1,numero2,soma;
	char sexo, nome[4];
	float nota;
	double nota2;
	bool presenca;
	
	printf ("digite numero1= ");
	scanf ("%i", &numero1);
	printf ("digite numero2= ");
	scanf ("%i", &numero2);
	printf ("digite o sexo= ");
	scanf ("%c", &sexo);
	printf ("digite o nome= ");
	scanf ("%c", &nome);
	printf ("digite a nota= ");
	scanf ("%f", &nota);
	printf ("digite a nota2= ");
	scanf ("%lf", &nota2);
	printf ("digite a presenca= ");
	scanf ("%b", &presenca);
	
	
	}
